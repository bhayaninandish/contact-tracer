<?php

$conn = new mysqli("sgp-project.cjw0kir1ggmp.us-east-1.rds.amazonaws.com","nisarg","nisarg16","sgpproject");

if($conn->connect_error){
    die('Database error'. $conn->connect_error);
}